<?php
use PHPUnit\Framework\TestCase;
use test\Client;
class MyGreeter_Client_Test extends TestCase
{
    public function get_class()
    {
        return __Class__;
    }

    public function getGreeting()
    {
        $hour = date('H',time());
        //取整
        $hour = intval($hour);
        //进行判断输出
        if($hour>=6&&$hour<=12){
            return "Good morning";
        }elseif($hour>12&&$hour<18){
            return "Good afternoon";
        }else{
            return "Good evening";
        }
    }


    public function test_Instance()
    {
        $this->assertEquals(
            get_class(),
            'MyGreeter_Client_Test'
        );
    }

    public function test_getGreeting()
    {
        $this->assertTrue(
            strlen($this->getGreeting()) > 0
        );
    }
}
